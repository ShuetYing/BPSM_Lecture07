# This is my better script
# Done using different approaches
# This script is nto going to work
# This script is not that good
